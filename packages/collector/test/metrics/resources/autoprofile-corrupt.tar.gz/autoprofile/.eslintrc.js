module.exports = {
  extends: '../../.eslintrc.js',

  rules: {
    'class-methods-use-this': 'off'
  }
};
